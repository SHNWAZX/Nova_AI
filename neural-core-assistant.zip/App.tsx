import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { AppMode, Message, GroundingSource, Attachment, AspectRatio } from './types';
import Brain from './components/Brain';
import { createPcmBlob, decodeAudioData, PCM_SAMPLE_RATE } from './utils/audio';

// Ensure cross-browser AudioContext support
declare global {
  interface Window {
    webkitAudioContext: typeof AudioContext;
  }
}

// ICONS
const MicIcon = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>;
const StopIcon = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>;
const SendIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>;
const TrashIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>;
const AttachIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>;
const SpeakerIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>;
const SettingsIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>;

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.IDLE);
  const [inputStr, setInputStr] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [volume, setVolume] = useState(0);
  const [isThinking, setIsThinking] = useState(false);
  const [brainMode, setBrainMode] = useState<'idle' | 'listening' | 'speaking' | 'thinking'>('idle');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("1:1");
  const [showSettings, setShowSettings] = useState(false);
  
  // API setup
  const apiKey = process.env.API_KEY || ''; 
  const ai = useRef(new GoogleGenAI({ apiKey })).current;
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Audio Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  // Visualizer Refs
  const analyserRef = useRef<AnalyserNode | null>(null);
  const inputAnalyserRef = useRef<AnalyserNode | null>(null);
  const outputAnalyserRef = useRef<AnalyserNode | null>(null);
  
  // Live Session Refs
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const isConnectedRef = useRef(false);

  // Helper for System Alerts
  const handleError = (context: string, error: any) => {
    console.error(`${context} Error:`, error);
    let userMessage = "An internal system error occurred.";
    
    const msg = error instanceof Error ? error.message : String(error);
    
    if (msg.includes("API key") || msg.includes("401")) {
        userMessage = "AUTHENTICATION FAILURE: Invalid or missing API Key.";
    } else if (msg.includes("quota") || msg.includes("429")) {
        userMessage = "SYSTEM OVERLOAD: API rate limit exceeded.";
    } else if (msg.includes("fetch failed") || msg.includes("network")) {
        userMessage = "NETWORK ERROR: Unable to reach Neural Core.";
    } else if (msg.includes("Permission denied") || msg.includes("NotAllowedError")) {
        userMessage = "ACCESS DENIED: Microphone permission required.";
    } else if (msg.includes("NotFoundError")) {
        userMessage = "HARDWARE ERROR: No microphone detected.";
    }

    setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: `[SYSTEM ALERT] ${userMessage}`,
        timestamp: Date.now()
    }]);
    setIsThinking(false);
    setBrainMode('idle');
  };

  // Initialization
  useEffect(() => {
    if (!process.env.API_KEY) {
        handleError("Init", new Error("API Key missing"));
    } else {
        setMessages([{
            id: 'system-init',
            role: 'model',
            text: 'NEURAL CORE ONLINE.\nMulti-modal systems active: Voice, Vision, Audio, and Video Generation enabled.',
            timestamp: Date.now()
        }]);
    }
    
    const loop = () => {
        updateVolume();
        requestAnimationFrame(loop);
    };
    const handle = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(handle);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- VISUALIZER ---
  const updateVolume = () => {
    if (analyserRef.current) {
      const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
      analyserRef.current.getByteFrequencyData(dataArray);
      const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
      setVolume(prev => prev * 0.8 + (Math.min(1, avg / 100)) * 0.2);
    } else {
        setVolume(prev => prev * 0.9);
    }
  };

  // --- AUDIO UTILS ---
  const initAudioContext = () => {
    if (!audioContextRef.current) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        audioContextRef.current = new AudioContextClass({ sampleRate: 24000 });
        outputAnalyserRef.current = audioContextRef.current.createAnalyser();
        outputAnalyserRef.current.fftSize = 64;
        outputAnalyserRef.current.connect(audioContextRef.current.destination);
    }
    return audioContextRef.current;
  };

  const playAudio = async (base64Data: string) => {
      const ctx = initAudioContext();
      if (!outputAnalyserRef.current) return;

      try {
          analyserRef.current = outputAnalyserRef.current;
          setBrainMode('speaking');
          
          const buffer = await decodeAudioData(base64Data, ctx);
          const source = ctx.createBufferSource();
          source.buffer = buffer;
          source.connect(outputAnalyserRef.current);
          
          source.start(0);
          source.onended = () => {
              setBrainMode('idle');
              analyserRef.current = null;
          };
      } catch (e) {
          console.error("Audio playback error", e);
      }
  };

  // --- GEMINI LIVE (VOICE) ---
  const startLiveSession = async () => {
    if (!apiKey) return handleError('Live', new Error('API Key missing'));
    
    setMode(AppMode.LIVE);
    setBrainMode('listening');
    setIsThinking(false);

    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        inputContextRef.current = new AudioContextClass({ sampleRate: PCM_SAMPLE_RATE });
        
        const source = inputContextRef.current.createMediaStreamSource(stream);
        const processor = inputContextRef.current.createScriptProcessor(4096, 1, 1);
        
        inputAnalyserRef.current = inputContextRef.current.createAnalyser();
        inputAnalyserRef.current.fftSize = 64;
        source.connect(inputAnalyserRef.current);
        analyserRef.current = inputAnalyserRef.current;

        initAudioContext(); // Init output context

        sessionPromiseRef.current = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-09-2025',
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
            },
            systemInstruction: "You are Neural, an advanced AI assistant in a holographic interface. You are concise and witty."
          },
          callbacks: {
            onopen: () => {
              isConnectedRef.current = true;
              processor.onaudioprocess = (e) => {
                 const inputData = e.inputBuffer.getChannelData(0);
                 const blob = createPcmBlob(inputData);
                 sessionPromiseRef.current?.then(session => {
                    session.sendRealtimeInput({ media: blob });
                 }).catch(() => {});
              };
              source.connect(processor);
              processor.connect(inputContextRef.current!.destination);
            },
            onmessage: async (msg: LiveServerMessage) => {
               if (msg.serverContent?.interrupted) {
                   sourcesRef.current.forEach(s => { try { s.stop(); } catch(e){} });
                   sourcesRef.current.clear();
                   nextStartTimeRef.current = 0;
                   if(inputAnalyserRef.current) analyserRef.current = inputAnalyserRef.current;
                   setBrainMode('listening');
                   return;
               }
               const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
               if (audioData) {
                 if(outputAnalyserRef.current) analyserRef.current = outputAnalyserRef.current;
                 setBrainMode('speaking');
                 const ctx = audioContextRef.current;
                 if (ctx) {
                    nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                    const buffer = await decodeAudioData(audioData, ctx);
                    const bufferSource = ctx.createBufferSource();
                    bufferSource.buffer = buffer;
                    bufferSource.connect(outputAnalyserRef.current!);
                    bufferSource.start(nextStartTimeRef.current);
                    nextStartTimeRef.current += buffer.duration;
                    sourcesRef.current.add(bufferSource);
                    bufferSource.onended = () => {
                        sourcesRef.current.delete(bufferSource);
                        if (sourcesRef.current.size === 0) {
                            setBrainMode('listening');
                            if(inputAnalyserRef.current) analyserRef.current = inputAnalyserRef.current;
                        }
                    };
                 }
               }
            },
            onclose: () => stopLiveSession(),
            onerror: (e) => { handleError('Live', e); stopLiveSession(); }
          }
        });
    } catch (err) {
        handleError('Live Setup', err);
        setMode(AppMode.IDLE);
        setBrainMode('idle');
    }
  };

  const stopLiveSession = () => {
    setMode(AppMode.IDLE);
    setBrainMode('idle');
    isConnectedRef.current = false;
    inputContextRef.current?.close();
    inputContextRef.current = null;
    audioContextRef.current?.close();
    audioContextRef.current = null;
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    analyserRef.current = null;
  };

  // --- MULTI-MODAL HANDLER ---
  const handleSendMessage = async () => {
    if (!inputStr.trim() && !attachment) return;
    if (!apiKey) return handleError("API", new Error("API Key missing"));

    const userMsg: Message = {
        id: Date.now().toString(),
        role: 'user',
        text: inputStr,
        timestamp: Date.now(),
        attachment: attachment || undefined
    };

    setMessages(prev => [...prev, userMsg]);
    setInputStr('');
    setAttachment(null);
    setMode(AppMode.SEARCH);
    setIsThinking(true);
    setBrainMode('thinking');

    try {
        let responseText = "";
        let sources: GroundingSource[] = [];
        let generatedImage = undefined;
        let generatedVideo = undefined;

        const lowerInput = userMsg.text.toLowerCase();

        // 1. AUDIO TRANSCRIPTION
        if (userMsg.attachment?.type === 'audio') {
            const resp = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: {
                    parts: [
                        { inlineData: { mimeType: userMsg.attachment.mimeType, data: userMsg.attachment.base64 } },
                        { text: userMsg.text || "Transcribe this audio." }
                    ]
                }
            });
            responseText = resp.text || "Transcription failed.";
        }
        // 2. VIDEO GENERATION (VEO)
        else if (lowerInput.includes("create video") || lowerInput.includes("generate video") || (userMsg.attachment?.type === 'image' && lowerInput.includes("video"))) {
            let operation;
            if (userMsg.attachment?.type === 'image') {
                 operation = await ai.models.generateVideos({
                    model: 'veo-3.1-fast-generate-preview',
                    image: { imageBytes: userMsg.attachment.base64, mimeType: userMsg.attachment.mimeType },
                    prompt: userMsg.text,
                    config: { numberOfVideos: 1, resolution: '720p', aspectRatio: '16:9' }
                });
            } else {
                operation = await ai.models.generateVideos({
                    model: 'veo-3.1-fast-generate-preview',
                    prompt: userMsg.text,
                    config: { numberOfVideos: 1, resolution: '720p', aspectRatio: '16:9' }
                });
            }
            
            // Poll for video
            while (!operation.done) {
                await new Promise(r => setTimeout(r, 5000));
                operation = await ai.operations.getVideosOperation({operation});
            }
            const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (videoUri) {
                generatedVideo = `${videoUri}&key=${apiKey}`;
                responseText = "Video generation complete.";
            } else {
                responseText = "Failed to generate video.";
            }
        }
        // 3. IMAGE GENERATION (PRO)
        else if ((lowerInput.startsWith("create") || lowerInput.startsWith("generate") || lowerInput.startsWith("draw")) && lowerInput.includes("image")) {
             const resp = await ai.models.generateContent({
                model: 'gemini-3-pro-image-preview',
                contents: { parts: [{ text: userMsg.text }] },
                config: { imageConfig: { aspectRatio: aspectRatio } }
