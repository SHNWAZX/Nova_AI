import React, { useEffect, useRef } from 'react';

interface BrainProps {
  isActive: boolean;
  volume: number; // 0 to 1
  mode: 'idle' | 'listening' | 'speaking' | 'thinking';
}

const Brain: React.FC<BrainProps> = ({ isActive, volume, mode }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;
    
    // Particles
    const particles: { x: number; y: number; vx: number; vy: number; size: number; life: number }[] = [];
    const numParticles = 60;
    
    const resize = () => {
      canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      canvas.height = canvas.parentElement?.clientHeight || 400;
    };
    window.addEventListener('resize', resize);
    resize();

    const render = () => {
      time += 0.01;
      
      // Clear with fade for trail effect
      ctx.fillStyle = 'rgba(5, 5, 5, 0.2)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      
      // Base pulsing sphere radius
      const baseRadius = 80;
      const pulse = Math.sin(time * 2) * 5;
      const audioReact = volume * 100; // Expand based on volume
      const currentRadius = baseRadius + pulse + audioReact;

      // Color determination
      let r = 100, g = 100, b = 255; // Default Blue
      if (mode === 'listening') { r = 255; g = 50; b = 50; } // Red
      else if (mode === 'speaking') { r = 50; g = 255; b = 100; } // Green
      else if (mode === 'thinking') { r = 200; g = 100; b = 255; } // Purple

      // Draw Central Core
      const gradient = ctx.createRadialGradient(centerX, centerY, currentRadius * 0.2, centerX, centerY, currentRadius);
      gradient.addColorStop(0, `rgba(${r}, ${g}, ${b}, 0.8)`);
      gradient.addColorStop(1, `rgba(${r}, ${g}, ${b}, 0)`);
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, currentRadius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();

      // Rings
      ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, 0.3)`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(centerX, centerY, currentRadius + 10, 0, Math.PI * 2);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, currentRadius + 30 + Math.sin(time) * 10, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, 0.1)`;
      ctx.stroke();

      // Particles System (Neural connections)
      if (particles.length < numParticles) {
         const angle = Math.random() * Math.PI * 2;
         const dist = currentRadius + Math.random() * 50;
         particles.push({
           x: centerX + Math.cos(angle) * dist,
           y: centerY + Math.sin(angle) * dist,
           vx: (Math.random() - 0.5) * 0.5,
           vy: (Math.random() - 0.5) * 0.5,
           size: Math.random() * 2 + 1,
           life: 1.0
         });
      }

      particles.forEach((p, index) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.005;
        
        // Orbit effect
        const dx = p.x - centerX;
        const dy = p.y - centerY;
        const dist = Math.sqrt(dx*dx + dy*dy);
        
        if (dist > currentRadius + 100 || p.life <= 0) {
          particles.splice(index, 1);
          return;
        }

        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${p.life})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        // Connect nearby particles
        particles.forEach(p2 => {
          const dx2 = p.x - p2.x;
          const dy2 = p.y - p2.y;
          const d2 = Math.sqrt(dx2*dx2 + dy2*dy2);
          if (d2 < 30) {
            ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${p.life * 0.2})`;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        });
      });

      animationFrameId = requestAnimationFrame(render);
    };
    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [isActive, volume, mode]);

  return (
    <canvas 
      ref={canvasRef} 
      className="w-full h-full absolute top-0 left-0 z-0 pointer-events-none"
    />
  );
};

export default Brain;