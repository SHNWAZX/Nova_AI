export enum AppMode {
  IDLE = 'IDLE',
  LIVE = 'LIVE',
  SEARCH = 'SEARCH'
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  sources?: GroundingSource[];
  attachment?: Attachment;
  generatedImage?: string; // base64
  generatedVideo?: string; // uri
}

export interface Attachment {
    base64: string;
    mimeType: string;
    type: 'image' | 'video' | 'audio';
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface AudioVisualizerData {
  volume: number;
  history: number[];
}

export type AspectRatio = "1:1" | "3:4" | "4:3" | "9:16" | "16:9";